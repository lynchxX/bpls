<div class="col-sm-12">
				<p class="back-link">Business Proceeds and Lquidation System <a href="#">BLPS</a></p>
			</div>